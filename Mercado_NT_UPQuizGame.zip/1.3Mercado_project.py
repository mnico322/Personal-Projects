#Nicolai T. Mercado
#2024-03243
#CMSC 56 Y-2L
#Project (YUPI: The Game Show!)

'''
Thought process of the game:
create 5 topics about UP
topics:
History of UP
Facts of UP
UP Campus specific questions
Degree programs
UPCAT superstitions/UPCAT related questions
more to be added if necessary

each topic has 15-20 questions
3 rounds, 1 round = 5 questions
questions are multiple choice answerable

pointing system:
0 questions right = 5.0
1 question right = 3.0
2 questions right = 2.5
3 questions right = 2.0
4 questions right = 1.5
5 questions right = 1.0

every 2nd question of the round, gain power up, power ups can repeat
power ups:
Lucky UPCAT pencil: remove 2 wrong choices
Call an iskx: Since this is a digital game, friends will have a 90% chance of giving the correct answer
    Finals Season: if player gets the question right, they will get the equivalent of 2 questions correct, else they will get the equivalent of 2 questions wrong

Only 1 power up can be used at a time
power up expires after round ends

At the end of the game, if the player's score can beat someone else's score in the top 10 or matches it equally, they will overwrite the current player's spot in the leaderboard
'''

#Topic 1
topic1 = {}

readhandle1 = open('Topic1.dat', 'r')
datalst1 = []
data1 = []
for line in readhandle1:
        newlist = line[:-1]
        datalst1.append(newlist)
for i in datalst1:
    a = i.split(',')
    data1.append(a)
readhandle1.close()
topic1['0'] = data1[0][1]
data1.pop(0)
for j in data1:
    topic1[j[0]] = [j[1], [j[2], j[3], j[4], j[5]]]

#Topic 2
topic2 = {}
readhandle2 = open('Topic2.dat', 'r')
datalst2 = []
data2 = []
for line in readhandle2:
        newlist = line[:-1]
        datalst2.append(newlist)
for i in datalst2:
    a = i.split(',')
    data2.append(a)
readhandle2.close()
topic2['0'] = data2[0][1]
data2.pop(0)
for j in data2:
    topic2[j[0]] = [j[1], [j[2], j[3], j[4], j[5]]]

#Topic 3
topic3 = {}
readhandle3 = open('Topic3.dat', 'r')
datalst3 = []
data3 = []
for line in readhandle3:
        newlist = line[:-1]
        datalst3.append(newlist)
for i in datalst3:
    a = i.split(',')
    data3.append(a)
readhandle3.close()
topic3['0'] = data3[0][1]
data3.pop(0)
for j in data3:
    topic3[j[0]] = [j[1], [j[2], j[3], j[4], j[5]]]

#Topic 4
topic4 = {}
readhandle4 = open('Topic4.dat', 'r')
datalst4 = []
data4 = []
for line in readhandle4:
        newlist = line[:-1]
        datalst4.append(newlist)
for i in datalst4:
    a = i.split(',')
    data4.append(a)
readhandle4.close()
topic4['0'] = data4[0][1]
data4.pop(0)
for j in data4:
    topic4[j[0]] = [j[1], [j[2], j[3], j[4], j[5]]]

#Topic 5
topic5 = {}
readhandle5 = open('Topic5.dat', 'r')
datalst5 = []
data5 = []
for line in readhandle5:
        newlist = line[:-1]
        datalst5.append(newlist)
for i in datalst5:
    a = i.split(',')
    data5.append(a)
readhandle5.close()
topic5['0'] = data5[0][1]
data5.pop(0)
for j in data5:
    topic5[j[0]] = [j[1], [j[2], j[3], j[4], j[5]]]

import random
print()
import time
print("Hello, Player!")
time.sleep(1)
print('''
                                                                                                              
                        -=-:                                                                                  
                       -+*++-                                          .:--=++++++++=-:.                      
                       .###*                                       :-+*####***##***#*###**+-.                 
                     ..:*##+.                                   :+*####****+**###+##+*+#***##*=.              
                  =+----=+=-::-==.                           .=*#######+*****####*#*******######*-            
              .-+*###+===++=-=*##**=.                  .-:..=*##############********###***########*- .::.     
    ..   .:-=+#*+-: :##*+++****  :=+*+-:.                =*#*******#*#*#***###%%%%###*****##********#*:       
 .--==------:        =#*#*###*.      .:====---:          +****###*****+***#*%#*#*##%##**+******#******-       
                     :#%#####=               .:.:      .+##**#**********+++##%#%#*%##*++*********###*##=      
                     :#######=                         +##*****##*##***+**+#*####*###+*+*+**#**##***+###-     
                     =*##*###+.                       =##**#####+#%%%#**++*+**###*=++++***#%%%#*##****##*:    
                     *##%#%%##-                      .*##****##+#%%%%%%**+++++###*=++**##%%%%%%#*##****##+    
                     *###*####=                      -##*****#**%%%%%%%%%%#*#*****+###%%%%%%%%%%*##*****#*.   
                     ###%%%###=                      =##****##+%%%%%%%%%%%%%#+*+*++#%%%%%%%%%%%%#*#*****##:   
                     ##%%#%%%#.                      +##**#*##+%%%%%%%%%***************#%%%%%%%%#+#**#####-   
                     *###:#%%*                       =##****##+%%%%%%%%%*##****##******%%%%%%%%%#*#*****##-   
                     =%## #%%-                       -##*****#**%%%%%%%%*#**+++*++**+**%%%%%%%%%*##*****#*.   
                     .%%%-#%%                        .*#**+**##+#%%%%%%%*#*##*+**+*****%%%%%%%%#*##*#**##+    
                     -%%%%%%#                         =##**#**##+#%%%%%%*###***+***###*%%%%%%%#*####+**#*:    
                     =%%%%%%#:                         +##****###*#%%%%%*##***+**##*##*%%%%%%**##*****##-     
                     =#%%%%##:                         .+##******#**#%%%***##*+*#++****%%%%#**#******##=      
                     +%%%%%%*                            +##***+**##***#%*###########*#%#**##******##*-       
                      #%%%%%=                             -*###+*****##****###%#%%###****##**#***###+.        
                      =%%%###.                             .=*##**#**#######********######****#*##*-          
                      =%##***                                .=*##**#######*#*****#**#######**##*-            
                    .=*#*#+=+.                                  :+*########+#***+#++**#######*=:              
                  .==++++++*=::                                    :=+*####*##*#**#**####*+-.                 
                :-+=:+===##++--=                                       .:--=++++++++=-:.                      
               ---:-+=:-+++::=*=:      
      ''')
time.sleep(1)
print('''
_____.___.            .__      ___________.__               ________                          _________.__                  ._.
\__  |   |__ ________ |__| /\  \__    ___/|  |__   ____    /  _____/_____    _____   ____    /   _____/|  |__   ______  _  _| |
 /   |   |  |  \____ \|  | \/    |    |   |  |  \_/ __ \  /   \  ___\__  \  /     \_/ __ \   \_____  \ |  |  \ /  _ \ \/ \/ / |
 \____   |  |  /  |_> >  | /\    |    |   |   Y  \  ___/  \    \_\  \/ __ \|  Y Y  \  ___/   /        \|   Y  (  <_> )     / \|
 / ______|____/|   __/|__| \/    |____|   |___|  /\___  >  \______  (____  /__|_|  /\___  > /_______  /|___|  /\____/ \/\_/  __
 \/            |__|                            \/     \/          \/     \/      \/     \/          \/      \/               \/                                                                                                                                                                                                                                        
      ''')
time.sleep(1)
print('(The Image of the Oblation and Isignia Belong to UP. I DO NOT OWN ANY of these Images.)')
time.sleep(1)
print('(Credits to ASCII Generator for creating the oblation, UP insignia, and Title Text Art.)')
time.sleep(1)

#Load Leaderboard function will automatically start upon running the program



def mainmenu():
    print()
    print('What would you like to do?')
    print("    [1] Start Game")
    print("    [2] View Instructions")
    print("    [3] View Leaderboard (Easy Mode)")
    print("    [4] View Leaderboard (Hard Mode)")
    print("    [0] Exit")
    choice=int(input("Select Option: "))
    return choice

#For condition that function1 has a high score in easy mode:
def highscore_easy():
    readhandle = open('easy.dat', 'r')
    gamedatacomma = []
    gamedata = []
    for line in readhandle:
        newlist = line[:-1]
        gamedatacomma.append(newlist)
    for i in gamedatacomma:
        a = i.split(',')
        gamedata.append(a)
    readhandle.close()
    return gamedata

#For condition that function1 has a high score in hard mode:
def highscore_hard():
    readhandle = open('hard.dat', 'r')
    gamedatacomma = []
    gamedata = []
    for line in readhandle:
        newlist = line[:-1]
        gamedatacomma.append(newlist)
    for i in gamedatacomma:
        a = i.split(',')
        gamedata.append(a)
    readhandle.close()
    return gamedata

def naming():
    while True:
        name = input('Enter your name here: ')
        if len(name) <= 2:
            print('Please Input at least 3 characters!')
            return naming()
        if len(name) > 10:
            print('That name is too long! Please limit it to 3-10 characters!')
            return naming()
        else:
            return name

topicorder = [topic1, topic2, topic3, topic4, topic5] #listing the dictionaries


#For function 1: the game itself
def game(topicorder):
    questioncounter = 0
    finalgrade = 0
    print()
    time.sleep(1)
    print('Choose your difficulty: ')
    time.sleep(1)
    print("    [1] Easy Mode (Choose your topics, topics can repeat)")
    print("    [2] Hard Mode (Topics are choosen at random)")
    difficulty = int(input('Select how the topics will be chosen: '))

    if difficulty == 1:
        time.sleep(1)
        print()
        print('Choose 1st Topic: ')
        print("    [0] History of UP (Hard difficulty)")
        print("    [1] Facts of UP (Hard difficulty)")
        print("    [2] UP Campus Specfic Questions (Medium difficulty)")
        print("    [3] Campus Degree Progams (Medium difficulty)")
        print("    [4] UPCAT superstitions/UPCAT related questions (Easy Difficulty)")
        a = int(input('Input the first topic you want: '))
        b = int(input('Input the second topic you want: '))
        c = int(input('Input the second topic you want: '))
        topicorder = [topicorder[a], topicorder[b], topicorder[c]]
        
    if difficulty == 2:
        time.sleep(1)
        random.shuffle(topicorder) # Shuffling the dictionary order
        topicorder.pop()
        topicorder.pop() #Taking only the first 3 dictionaries
    for i in topicorder: #Gets each topic in the reduced list of topics
        powerups = {
    '1':['Lucky UPCAT Pencil', "Remove 2 wrong choices"],
    '2':['Call an Iskx', 'Ask an Iskx on what the answer might be (Iskx has a 90 percent chance of getting it right)'],
    '3':['Finals Season','get the equivalent of 2 questions correct. But, a wrong will cost you a point']
}   #Dictionary of powerups
        print('The selected topic is:', i['0'])
        time.sleep(1)
        print()
        score = 0 #Predefining the score
        listofkeys = [] #used for pre defining the list of all keys in each topic
        powerupcount = 0 #Count for when second round ends and third round starts
        powerupskey = ['1', '2', '3'] #Keys for power ups dictionary
        random.shuffle(powerupskey) #Shuffling the powerup
        powerup = powerupskey[0] #Getting the first powerup of the shuffled list
        powerupname = powerups[powerup][0] #PowerUP name
        powerupdesc = powerups[powerup][1] #PowerUP Description
        usepower = 0 #Counter for if powerup exists or not
        
        for k in i: 
            listofkeys.append(k) #Listing all of the keys in each topic
        listofkeys.pop(0)
        random.shuffle(listofkeys) #Shuffling the keys
        listofkeys = listofkeys[0:5] #Taking only 5

        for k in listofkeys: #Question by question
            questioncounter += 1
            powerupcount += 1
            listofanswers = [i[k][1][0], i[k][1][1], i[k][1][2], i[k][1][3]]
            random.shuffle(listofanswers) #Shuffling the list of answers
            if powerupcount == 3: #Will trigger after 3 rounds have taken place
                print('You have unlocked the', powerupname, 'PowerUP!')
                time.sleep(1)
                print('With this you can', powerupdesc)
                time.sleep(1)
                print()
                usepower = 1
                powerupcount -= 3
            print(str(questioncounter) + '. ' + i[k][0]) #Printing the question
            time.sleep(1)
            if usepower == 0:
                print("    [1]", listofanswers[0])
                print("    [2]", listofanswers[1])
                print("    [3]", listofanswers[2])
                print("    [4]", listofanswers[3])
                ans = int(input('What is your answer?: ')) - 1 #Getting the input of users answer
                time.sleep(1)
                print()
                verifyans = listofanswers[ans]
                if verifyans == i[k][1][0]: #Checking if user has correct answer
                    print('That is correct!') 
                    time.sleep(1)
                    print()
                    score += 1
                else:
                    print('Sorry! that is incorrect')
                    time.sleep(1)
                    print('The correct answer is:', i[k][1][0])
                    time.sleep(1)
                    print()
            elif usepower == 1:
                print("    [1]", listofanswers[0])
                print("    [2]", listofanswers[1])
                print("    [3]", listofanswers[2])
                print("    [4]", listofanswers[3])
                print("    [5]", 'Use PowerUP:', powerupname)
                if questioncounter % 5 == 0:
                    print('NOTE: PowerUP will be discarded after this question')
                ans = int(input('What is your answer?: ')) - 1 #Getting the input of users answer
                time.sleep(1)
                print()
                if ans == 4:
                    if powerup == '1':
                        print('PowerUP Activated!')
                        time.sleep(1)
                        print()
                        usepower -= 1
                        listofanswers = [i[k][1][0], i[k][1][1]]
                        print(str(questioncounter) + '. ' + i[k][0]) #Printing the question
                        random.shuffle(listofanswers) #Shuffling the list of answers
                        print("    [1]", listofanswers[0])
                        print("    [2]", listofanswers[1])
                        newans = int(input('What is your answer?: ')) - 1 #Getting the input of users answer
                        time.sleep(1)
                        verifyans = listofanswers[newans]
                        if verifyans == i[k][1][0]: #Checking if user has correct answer
                            print('That is correct!')
                            time.sleep(1)
                            print()
                            score += 1
                        else:
                            print('Sorry! that is incorrect')
                            time.sleep(1)
                            print('The correct answer is:', i[k][1][0])
                            time.sleep(1)
                            print()
                    elif powerup == '2':
                        print('PowerUP Activated!')
                        time.sleep(1)
                        print()
                        print(str(questioncounter) + '. ' + i[k][0]) #Printing the question
                        print("    [1]", listofanswers[0])
                        print("    [2]", listofanswers[1])
                        print("    [3]", listofanswers[2])
                        print("    [4]", listofanswers[3])
                        usepower -=1
                        chancelist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                        random.shuffle(chancelist)
                        iskx = chancelist[0]
                        if iskx == 7: #If first integer is 7 after shuffling, a wrong answer will be recommended
                            print('Iskx says the correct answer is', i[k][1][1], '(There is a 90 percent chance iskx is correct)')
                        else:
                            print('Iskx says the correct answer is', i[k][1][0], '(There is a 90 percent chance iskx is correct)')
                        newans = int(input('What is your answer?: ')) - 1 #Getting the input of users answer
                        time.sleep(1)
                        verifyans = listofanswers[newans]
                        if verifyans == i[k][1][0]: #Checking if user has correct answer
                            print('That is correct!') 
                            time.sleep(1)
                            score += 1
                        else:
                            print('Sorry! that is incorrect')
                            time.sleep(1)
                            print('The correct answer is:', i[k][1][0])
                            time.sleep(1)
                            print()
                    elif powerup == '3':
                        usepower -= 1
                        print('PowerUP Activated!')
                        time.sleep(1)
                        print()
                        print(str(questioncounter) + '. ' + i[k][0]) #Printing the question
                        print("    [1]", listofanswers[0])
                        print("    [2]", listofanswers[1])
                        print("    [3]", listofanswers[2])
                        print("    [4]", listofanswers[3])
                        newans = int(input('What is your answer?: ')) - 1 #Getting the input of users answer
                        time.sleep(1)
                        verifyans = listofanswers[newans]
                        if verifyans == i[k][1][0]: #Checking if user has correct answer
                            print('That is correct! You gain double points!')
                            time.sleep(1)
                            print()
                            score += 2
                        else:
                            print('Sorry! that is incorrect, you dont gain a point and lose one!')
                            time.sleep(1)
                            print('The correct answer is:', i[k][1][0])
                            time.sleep(1)
                            print()
                            score -= 1
                elif ans == 1 or ans == 2 or ans == 3 or ans == 0:
                    verifyans = listofanswers[ans]
                    if verifyans == i[k][1][0]: #Checking if user has correct answer
                        print('That is correct!') 
                        time.sleep(1)
                        print()
                        score += 1
                    else:
                        print('Sorry! that is incorrect')
                        time.sleep(1)
                        print('The correct answer is:', i[k][1][0])
                        time.sleep(1)
                        print()
        if score <= 0:
            grade = 5.0
        elif score == 1:
            grade = 3.0
        elif score == 2:
            grade = 2.5
        elif score == 3:
            grade = 2.0
        elif score == 4:
            grade = 1.5
        elif score >= 5:
            grade = 1.0

        finalgrade += grade
        time.sleep(1)
        print('You got a score of', score, 'Your grade for this round is', grade)
        print()
        if usepower == 1:
            print('You did not use your', powerupname, 'PowerUP this round. It will now be discarded.')
            print()
    finalgrade = round(finalgrade/3, 4)
    print('Your final grade for this game is', finalgrade)
    if finalgrade <= 1.75:
        if finalgrade <= 1.45:
            if finalgrade <= 1.20:
                print('Congratulations! You finished with Summa Cum Laude Standing!')
            else:
                print('Congratulations! You finished with Magna Cum Laude Standing!')
        else:
            print('Congratulations! You finished with Cum Laude Standing!')
        if finalgrade > 3.0:
            print('Continue to study, you can do it!')

    if difficulty == 1:
        lbdat = highscore_easy()
        scores = []
        for i in lbdat:
            scores.append(i)
        count = 0
        replace = 0
        for j in scores:
            count += 1
            if replace == 0:
                if finalgrade <= float(j[0]):
                    replace = 1
                    print('You have qualified to join the leaderboard!')
                    print('Please input your name (3-10 characters)')
                    name = naming()
                    qualifier = [str(finalgrade), name]
                    scores.insert(count - 1, qualifier)
                    scores.pop()
                    filehandle = open('easy.dat', 'w')
                    for i in scores:
                        filehandle.write(str(i[0]) + ',' + i[1] + '\n')
                    filehandle.close()
                    print('Your records have officially been added!')
                    print('Please Enter [3] in the main menu to view the easy leaderboard!')

    if difficulty == 2:
        lbdat = highscore_hard()
        scores = []
        for i in lbdat:
            scores.append(i)
        count = 0
        replace = 0
        for j in scores:
            count += 1
            if replace == 0:
                if finalgrade <= float(j[0]):
                    replace = 1
                    print('You have qualified to join the leaderboard!')
                    print('Please input your name (3-10 characters)')
                    name = naming()
                    qualifier = [str(finalgrade), name]
                    scores.insert(count - 1, qualifier)
                    scores.pop()
                    filehandle = open('hard.dat', 'w')
                    for i in scores:
                        filehandle.write(str(i[0]) + ',' + i[1] + '\n')
                    filehandle.close()
                    print('Your records have officially been added!')
                    print('Please Enter [4] in the main menu to view the hard leaderboard!')

#For Function 2: Viewing the instructions
def viewinstructions():
    print()
    print('Welcome to YUPI the gameshow!')
    def instructionsmenu():
        print()
        time.sleep(1)
        print('CONTROLS')
        print('- Control your answers with the [1] [2] [3] [4] [5] number keys')
        print("    [1]", 'Topics and Rounds')
        print("    [2]", 'PowerUPs')
        print("    [3]", 'Pointing System')
        print("    [4]", 'Leaderboard System')
        print("    [0]", 'Exit')
        insans = int(input('Input your answer here: '))
        return insans
    def Topicsandrounds(): 
        print()
        print('There are 5 topics in this game, these are:')
        time.sleep(1)
        print('History of UP (11 question pool)')
        time.sleep(1)
        print('Facts of UP (20 question pool)')
        time.sleep(1)
        print('UP Campus specific questions (20 question pool)')
        time.sleep(1)
        print('Degree programs (20 question pool)')
        time.sleep(1)
        print('UPCAT superstitions/UPCAT related questions (20 question pool)')
        time.sleep(1)
        print()
        print('There are 3 rounds, each round contains 5 questions.')
        time.sleep(1)
        print('Each round will be dedicated to 1 topic.')
        time.sleep(1)
        print('In easy mode, you may choose 3 topics. Topics may repeat')
        time.sleep(1)
        print('In Hard mode, topics are to be randomly selected from the pool of questions per topic.')
        time.sleep(1)

    def PowerUPs():
        print()
        print('Every 2nd question of the round, gain a PowerUP! PowerUPs can repeat.')
        time.sleep(1)
        print('PowerUP expires after round ends, a warning will be shown that the PowerUP will expire soon.')
        time.sleep(1)
        print('Here is a list of the possible PowerUPs you can get!')
        time.sleep(1)
        print('    -Lucky UPCAT pencil: remove 2 wrong choices')
        time.sleep(1)
        print('    -Call an iskx: Iskx will have a 90 percent chance of giving the correct answer')
        time.sleep(1)
        print('    -Finals Season: if player gets the question right, they will get the equivalent of 2 questions correct, else they will lose a point')
        time.sleep(1)

    def Pointingsystem():
        print()
        print('As stated in Topics and Rounds, there will be 3 rounds.')
        time.sleep(1)
        print('You will get a corresponding "Grade" based on how many questions your final score for that round')
        time.sleep(1)
        print('Here is the grading system based on the score obatined:')
        time.sleep(1)
        print('    5 or more = 1.0 ')
        print('    4 = 1.5 ')
        print('    3 = 2.0 ')
        print('    2 = 2.5 ')
        print('    1 = 3.0 ')
        print('    0 or less = 5.0 ')
        time.sleep(1)
        print('A "GWA" will be computed based on the average of the 3 grades obtained.')
        time.sleep(1)
        print('If your GWA is less than or equal to 1.75 but not more than 1.45, you will have Cum Laude standing!')
        print('If your GWA is less than or equal to 1.45 but not more than 1.20, you will have Magna Cum Laude standing!')
        print('If your GWA is greater than or equal to 1.20, you will have Summa Cum Laude standing!')
        print('If Your GWA is part of the top, you have a chance to join the leaderboard!')
        time.sleep(1)
    def leaderboard():
        time.sleep(1)
        print('If you reach a score higher or currently on the leaderboard, you will be given the honors of putting your own name there!')
        time.sleep(1)
        print('The leaderboard for easy and hard mode is different.')
        time.sleep(1)
        print('So give it your all and aim for number 1!')
    while True:
        option=instructionsmenu()
        if option==1:
            Topicsandrounds()

        elif option==2:
            PowerUPs()

        elif option==3:
            Pointingsystem()

        elif option==4:
            leaderboard()

        if option==0:
            break

#For Function 3: viewing the easy leaderboard
def view_leaderboard_easy():
    print()
    time.sleep(1)
    print('Here is the Easy Mode leaderboard:')
    time.sleep(1)
    print()
    datalist = highscore_easy()
    print('Rank  | Name       | Grade')
    count = 0
    for i in datalist:
        count += 1
        print(str(count) + ' '*(5 - len(str(count))) + ' | ' + i[1] + ' '*(11 - len(i[1])) + '| ' + str(i[0]))

#For Function 4: viewing the hard leaderboard
def view_leaderboard_hard():
    print()
    time.sleep(1)
    print('Here is the Hard Mode leaderboard:')
    time.sleep(1)
    print()
    datalist = highscore_hard()
    print('Rank  | Name       | Grade')
    count = 0
    for i in datalist:
        count += 1
        print(str(count) + ' '*(5 - len(str(count))) + ' | ' + i[1] + ' '*(11 - len(i[1])) + '| ' + str(i[0]))
     
while True:
    option=mainmenu()
    if option==1:
        game(topicorder)

    elif option==2:
        viewinstructions()

    elif option==3:
        view_leaderboard_easy()

    elif option==4:
        view_leaderboard_hard()

    if option==0:
        print('Bye! Thanks for for playing! Padayon!')
        break